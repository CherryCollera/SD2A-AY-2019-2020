﻿/*18-01133
Jairuz D. Nazareno
BSCS SD2A
January 27, 2020
This program will input and display my name*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample3_InputMyName
{
    class Sample3_InputMyName
    {
        static void Main(string[] args)
        {
            String firstname, lastname;
            System.Console.Write("Enter your name (firstname lastname) ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();

            System.Console.WriteLine("Hello " + firstname + lastname + "!!!\nWelcome to OOP environment.");
            System.Console.ReadKey();
        }
    }
}
