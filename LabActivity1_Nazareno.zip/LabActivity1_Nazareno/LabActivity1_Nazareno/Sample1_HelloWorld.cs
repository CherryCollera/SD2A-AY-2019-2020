﻿/*18-01133
Jairuz D. Nazareno
BSCS SD2A
January 27, 2020
This program will display the phrase "Hello World"*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1_HelloWorld
{
    class Sample1_HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
