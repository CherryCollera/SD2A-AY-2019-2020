﻿/* 18-03675
 Thomas Anthony D. Sanchez
 SD2A
 January 27, 2020
 This program will display the phrase "Hello World!"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile
{
    class Sample2_MyProfile
    {
        static void Main(string[] args)
        {
            Console.Write("Name\t\t:\tThomas Anthony D. Sanchez\n\n");
            Console.Write("Date of Birth\t:\tJanuary 28, 2000\n\n");
            Console.Write("Course\t\t:\tBS Computer Science\n\n");
            Console.Write("Year\t\t:\tII\n\n");
            Console.Write("Section\t\t:\tSD2A\n\n");
            Console.ReadKey();
        }
    }
}
