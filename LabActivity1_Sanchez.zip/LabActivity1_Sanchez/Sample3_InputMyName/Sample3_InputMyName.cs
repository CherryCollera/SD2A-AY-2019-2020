﻿/* 18-03675
 Thomas Anthony D. Sanchez
 SD2A
 January 27, 2020
 This program will display the phrase "Hello World!"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample3_InputMyName
{
    class Sample3_InputMyName
    {
        static void Main(string[] args)
        {
            string firstname, lastname;
            Console.Write("Enter your name (Firstname Lastname)");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();
            Console.WriteLine("\nHello " + firstname + " " + lastname + "!!!\nWelcome to OOP Environment.");
            Console.ReadKey();

        }
    }
}
