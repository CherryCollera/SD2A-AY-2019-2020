﻿/* NAZARENO, Jairuz D.
 * BSCS SD2A
 * 
 * This program will show the grade equivalent of your final grade. */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            double fgrade;
            string grade;
            Console.Write("Enter your final grade\t: ");
            grade = Console.ReadLine();
            if (grade == "INC" || grade == "inc")
            {
                Console.WriteLine("Grade Equivalent\t: INC\nRemarks\t\t\t: Incomplete");
            }
            else
            {
                fgrade = Convert.ToDouble(grade);
                if (fgrade <= 100 && fgrade >= 98)
                {
                    Console.WriteLine("Grade Equivalent\t: 1.00\nRemarks\t\t\t: Excellent");
                }
                else if (fgrade <= 97 && fgrade >= 95)
                {
                    Console.WriteLine("Grade Equivalent\t: 1.25\nRemarks\t\t\t: Excellent");
                }
                else if (fgrade <= 94 && fgrade >= 92)
                {
                    Console.WriteLine("Grade Equivalent\t: 1.50\nRemarks\t\t\t: Very Good");
                }
                else if (fgrade <= 91 && fgrade >= 89)
                {
                    Console.WriteLine("Grade Equivalent\t: 1.75\nRemarks\t\t\t: Very Good");
                }
                else if (fgrade <= 88 && fgrade >= 86)
                {
                    Console.WriteLine("Grade Equivalent\t: 2.00\nRemarks\t\t\t: Good");
                }
                else if (fgrade <= 85 && fgrade >= 83)
                {
                    Console.WriteLine("Grade Equivalent\t: 2.25\nRemarks\t\t\t: Good");
                }
                else if (fgrade <= 82 && fgrade >= 80)
                {
                    Console.WriteLine("Grade Equivalent\t: 2.50\nRemarks\t\t\t: Fair");
                }
                else if (fgrade <= 79 && fgrade >= 77)
                {
                    Console.WriteLine("Grade Equivalent\t: 2.75\nRemarks\t\t\t: Passed");
                }
                else if (fgrade <= 76 && fgrade >= 75)
                {
                    Console.WriteLine("Grade Equivalent\t: 3.00\nRemarks\t\t\t: Passed");
                }
                else if (fgrade <= 74 && fgrade >= 72)
                {
                    Console.WriteLine("Grade Equivalent\t: 4.00\nRemarks\t\t\t: Condiional");
                }
                else if (fgrade <= 71)
                {
                    Console.WriteLine("Grade Equivalent\t: 5.00\nRemarks\t\t\t: Failed");
                }
                else
                {
                    Console.WriteLine("Invalid input!");
                }
            }
            Console.ReadKey();
        }
        
    }
}
