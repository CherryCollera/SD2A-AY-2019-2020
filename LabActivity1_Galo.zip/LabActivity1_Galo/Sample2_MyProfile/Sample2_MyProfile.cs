﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile
{
    class Sample2_MyProfile
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Name \t\t:\t Joseph John C. Galo \n");
            System.Console.WriteLine("Date of Birth \t:\t January 30, 2000\n");
            System.Console.WriteLine("Course \t\t:\t BS Computer Science \n");
            System.Console.WriteLine("Year\t\t:\t II\n");
            System.Console.WriteLine("Section \t:\t 2A\n");
            System.Console.ReadKey();
        }
    }
}
