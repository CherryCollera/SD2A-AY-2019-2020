﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void BtnOne_Click(object sender, EventArgs e)
        {
            int number = 25;
            MessageBox.Show(number.ToString());
        }

        private void BtnTwo_Click(object sender, EventArgs e)
        {
            float number = 25.78F;
            MessageBox.Show(number.ToString());
        }

        private void BtnThree_Click(object sender, EventArgs e)
        {
            double number = 25.7889;
            MessageBox.Show(number.ToString());
        }

        private void BtnFour_Click(object sender, EventArgs e)
        {
            int firstTextboxNumber, secondTextboxNumber, sum;

            firstTextboxNumber = int.Parse(TbFirstNumber.Text);
            secondTextboxNumber = int.Parse(TbSecondNumber.Text);
            sum = firstTextboxNumber + secondTextboxNumber;
            MessageBox.Show("Sum is " + sum.ToString());
        }

        private void TbFirstNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void TbSecondNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
