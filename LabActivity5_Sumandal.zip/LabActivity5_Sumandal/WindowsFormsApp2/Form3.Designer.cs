﻿namespace WindowsFormsApp2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnOne = new System.Windows.Forms.Button();
            this.LblOne = new System.Windows.Forms.Label();
            this.TbFirstNumber = new System.Windows.Forms.TextBox();
            this.TbSecondNumber = new System.Windows.Forms.TextBox();
            this.LblTwo = new System.Windows.Forms.Label();
            this.BtnTwo = new System.Windows.Forms.Button();
            this.BtnThree = new System.Windows.Forms.Button();
            this.BtnFour = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnOne
            // 
            this.BtnOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOne.Location = new System.Drawing.Point(40, 69);
            this.BtnOne.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOne.Name = "BtnOne";
            this.BtnOne.Size = new System.Drawing.Size(265, 37);
            this.BtnOne.TabIndex = 0;
            this.BtnOne.Text = "Integer";
            this.BtnOne.UseVisualStyleBackColor = true;
            this.BtnOne.Click += new System.EventHandler(this.BtnOne_Click);
            // 
            // LblOne
            // 
            this.LblOne.AutoSize = true;
            this.LblOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblOne.Location = new System.Drawing.Point(63, 155);
            this.LblOne.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblOne.Name = "LblOne";
            this.LblOne.Size = new System.Drawing.Size(156, 18);
            this.LblOne.TabIndex = 3;
            this.LblOne.Text = "Enter First Number:";
            // 
            // TbFirstNumber
            // 
            this.TbFirstNumber.Location = new System.Drawing.Point(232, 155);
            this.TbFirstNumber.Margin = new System.Windows.Forms.Padding(4);
            this.TbFirstNumber.Name = "TbFirstNumber";
            this.TbFirstNumber.Size = new System.Drawing.Size(203, 22);
            this.TbFirstNumber.TabIndex = 4;
            this.TbFirstNumber.TextChanged += new System.EventHandler(this.TbFirstNumber_TextChanged);
            // 
            // TbSecondNumber
            // 
            this.TbSecondNumber.Location = new System.Drawing.Point(675, 155);
            this.TbSecondNumber.Margin = new System.Windows.Forms.Padding(4);
            this.TbSecondNumber.Name = "TbSecondNumber";
            this.TbSecondNumber.Size = new System.Drawing.Size(203, 22);
            this.TbSecondNumber.TabIndex = 6;
            this.TbSecondNumber.TextChanged += new System.EventHandler(this.TbSecondNumber_TextChanged);
            // 
            // LblTwo
            // 
            this.LblTwo.AutoSize = true;
            this.LblTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTwo.Location = new System.Drawing.Point(476, 155);
            this.LblTwo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTwo.Name = "LblTwo";
            this.LblTwo.Size = new System.Drawing.Size(179, 18);
            this.LblTwo.TabIndex = 5;
            this.LblTwo.Text = "Enter Second Number:";
            // 
            // BtnTwo
            // 
            this.BtnTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTwo.Location = new System.Drawing.Point(341, 69);
            this.BtnTwo.Margin = new System.Windows.Forms.Padding(4);
            this.BtnTwo.Name = "BtnTwo";
            this.BtnTwo.Size = new System.Drawing.Size(265, 37);
            this.BtnTwo.TabIndex = 7;
            this.BtnTwo.Text = "Float";
            this.BtnTwo.UseVisualStyleBackColor = true;
            this.BtnTwo.Click += new System.EventHandler(this.BtnTwo_Click);
            // 
            // BtnThree
            // 
            this.BtnThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnThree.Location = new System.Drawing.Point(642, 69);
            this.BtnThree.Margin = new System.Windows.Forms.Padding(4);
            this.BtnThree.Name = "BtnThree";
            this.BtnThree.Size = new System.Drawing.Size(265, 37);
            this.BtnThree.TabIndex = 8;
            this.BtnThree.Text = "Double";
            this.BtnThree.UseVisualStyleBackColor = true;
            this.BtnThree.Click += new System.EventHandler(this.BtnThree_Click);
            // 
            // BtnFour
            // 
            this.BtnFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFour.Location = new System.Drawing.Point(341, 224);
            this.BtnFour.Margin = new System.Windows.Forms.Padding(4);
            this.BtnFour.Name = "BtnFour";
            this.BtnFour.Size = new System.Drawing.Size(265, 37);
            this.BtnFour.TabIndex = 9;
            this.BtnFour.Text = "Compute Sum";
            this.BtnFour.UseVisualStyleBackColor = true;
            this.BtnFour.Click += new System.EventHandler(this.BtnFour_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(846, 274);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(86, 36);
            this.BtnExit.TabIndex = 10;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 322);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnFour);
            this.Controls.Add(this.BtnThree);
            this.Controls.Add(this.BtnTwo);
            this.Controls.Add(this.TbSecondNumber);
            this.Controls.Add(this.LblTwo);
            this.Controls.Add(this.TbFirstNumber);
            this.Controls.Add(this.LblOne);
            this.Controls.Add(this.BtnOne);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnOne;
        private System.Windows.Forms.Label LblOne;
        private System.Windows.Forms.TextBox TbFirstNumber;
        private System.Windows.Forms.TextBox TbSecondNumber;
        private System.Windows.Forms.Label LblTwo;
        private System.Windows.Forms.Button BtnTwo;
        private System.Windows.Forms.Button BtnThree;
        private System.Windows.Forms.Button BtnFour;
        private System.Windows.Forms.Button BtnExit;
    }
}