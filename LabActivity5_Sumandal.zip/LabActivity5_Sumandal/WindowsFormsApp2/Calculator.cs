﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void BtnOne_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnOne.Text;
        }

        private void BtnTwo_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnTwo.Text;
        }

        private void BtnThree_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnThree.Text;
        }

        private void BtnFour_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnFour.Text;
        }

        private void BtnFive_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnFive.Text;
        }

        private void BtnSix_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnSix.Text;
        }

        private void BtnSeven_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnSeven.Text;
        }

        private void BtnEight_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnEight.Text;
        }

        private void BtnNine_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnNine.Text;
        }

        private void BtnZero_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnZero.Text;
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtDisplay.Clear();
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(TxtDisplay.Text);
            TxtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void BtnEqual_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)
            {
                total2 = total1 + double.Parse(TxtDisplay.Text);
            }
            else if (minusButtonClicked == true)
            {
                total2 = total1 - double.Parse(TxtDisplay.Text);
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = total1 * double.Parse(TxtDisplay.Text);
            }
            else if (divideButtonClicked == true)
            {
                total2 = total1 / double.Parse(TxtDisplay.Text);
            }
            TxtDisplay.Text = total2.ToString();total1 = 0;
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(TxtDisplay.Text);
            TxtDisplay.Clear();

            minusButtonClicked = true;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(TxtDisplay.Text);
            TxtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(TxtDisplay.Text);
            TxtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }

        private void BtnPeriod_Click(object sender, EventArgs e)
        {
            TxtDisplay.Text = TxtDisplay.Text + BtnPeriod.Text;
        }

        private void BtnBackOne_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void TxtDisplay_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnGoThree_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();
        }
    }
}
