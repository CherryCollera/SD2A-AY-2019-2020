﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A       ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComAve
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            //this method computes the avegare grade of 5 subjects
            double sub1, sub2, sub3, sub4, sub5;
            double ave;
            Console.WriteLine("Enter five grades: ");
            sub1 = Convert.ToDouble(Console.ReadLine());
            sub2 = Convert.ToDouble(Console.ReadLine());
            sub3 = Convert.ToDouble(Console.ReadLine());
            sub4 = Convert.ToDouble(Console.ReadLine());
            sub5 = Convert.ToDouble(Console.ReadLine());
            ave = (sub1 + sub2 + sub3 + sub4 + sub5) / 5;
            Console.Write("The average is " + ave + ".");
            Console.ReadKey();
        }
    }
}
