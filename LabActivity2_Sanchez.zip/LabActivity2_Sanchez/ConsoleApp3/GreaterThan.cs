﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A       ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class GreaterThan
    {
        static void Main(string[] args)
        {
            //this method indentifies which of the two number is greater in value
            int num1, num2;
            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num1 > num2)
                Console.WriteLine(num1 + " is greater than " + num2 + ".");
            else if (num2 > num1)
                Console.WriteLine(num2 + " is greater than " + num1 + ".");
            else
                Console.WriteLine(num1 + " is equal to " + num2 + ".");
            Console.ReadKey();
        }
    }
}
