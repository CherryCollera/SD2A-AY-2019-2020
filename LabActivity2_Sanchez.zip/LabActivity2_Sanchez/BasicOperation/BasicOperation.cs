﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A       ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity2_Sanchez
{
    class BasicOperation

    {
        static void Main(string[] args)
        {
            int num1, num2, sum, difference, product;
            double quotient, remainder;
            /*this method computes for the sum, difference,
            product, quotient, and remainder of two numbers*/
            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            sum = num1 + num2;
            Console.Write("\nSum = " + sum);
            difference = num1 - num2;
            Console.Write("\nDifference = " + difference);
            product = num1 * num2;
            Console.Write("\nProduct = " + product);
            quotient = num1 / num2;
            Console.Write("\nQuotient = " + quotient);
            remainder = num1 % num2;
            Console.Write("\nRemainder = " + remainder);
            Console.ReadKey();
        }
    }
}
