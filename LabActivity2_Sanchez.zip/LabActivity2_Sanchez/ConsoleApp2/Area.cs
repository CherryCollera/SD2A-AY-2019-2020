﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A       ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclareConstants
{
    class Area
    {
        static void Main(string[] args)
        {
            /*this methods computes for the area of a
            circle with its radius and constant variable pi*/
            double radius, area;
            const double pi = 3.14159;
            Console.Write("Enter Radius of Circle:  ");
            radius = Convert.ToDouble(Console.ReadLine());
            area = pi * radius * radius;
            Console.WriteLine("Radius = {0:0.0000},\tArea = {1:0.0000}", radius, area);
            Console.ReadKey();
        }
    }
}
