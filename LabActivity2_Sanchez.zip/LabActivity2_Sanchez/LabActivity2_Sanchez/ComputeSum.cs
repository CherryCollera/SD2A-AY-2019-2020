﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A       ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity2_Sanchez
{
    class ComputeSum
    {
        static void Main(string[] args)
        {
            int num1, num2;
            //this method computes for the sum of two numbers
            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nSum = {0}", num1 + num2);
            Console.ReadKey();
        }
    }
}
