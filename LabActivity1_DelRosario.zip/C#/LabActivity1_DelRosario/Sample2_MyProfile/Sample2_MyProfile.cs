﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/** 
18-01531
Eli Raphael R. Del Rosario
SD2A
Jan 27, 2020
This Program will Display Hello World
**/

namespace Sample2_MyProfile
{
    class Sample2_MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name\t\t: \tEli Raphael R. Del Rosario\n");
            Console.WriteLine("Date of Birth\t:\tMarch 14,2000\n");
            Console.WriteLine("Course\t\t:\tBS Computer Science\n");
            Console.WriteLine("Year\t\t:\t2nd\n");
            Console.WriteLine("Section\t\t:\tSD2A\n");
            Console.ReadKey();

        }
    }
}
