﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/** 
18-01531
Eli Raphael R. Del Rosario
SD2A
Jan 27, 2020
This Program will Display Hello World
**/
     
     
namespace Sample1_HelloWorld
{
    class Sample1_HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
