﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNames
{
    class CompareName
    {
        static void Main(string[] args)
        {
            string grds;
            Console.WriteLine("Enter churvakels: ");
            grds = Console.ReadLine();

            grds = Convert.ToInt32(FormatException);
            Console.WriteLine(grds);

            /*
            string str1 = "Thom";
            string str2 = "Thom";
            string str3 = "Thomas";
            string str4 = "thomas";
            string str5 = "THOMAS";

            Console.WriteLine("Using Equals() Method");
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str2, String.Equals(str1, str2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str3, String.Equals(str1, str3));
            Console.WriteLine("\tLength of {0} is {1}", str1, str1.Length);
            Console.WriteLine("\tString {0} Substring(0, 3) will return {1}", str5, str5.Substring(0, 3));
            Console.WriteLine("Using Compare() Method");
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str2, String.Compare(str1, str2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str3, String.Compare(str1, str3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str3, str1, String.Compare(str3, str1));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str4, str5, String.Equals(str4, str5));
            Console.WriteLine("Using CompareTo() Method");
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str2, str1.CompareTo(str2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str1, str3, str1.CompareTo(str3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", str3, str1, str3.CompareTo(str1));
            */
            Console.ReadKey();
        }
    }
}
