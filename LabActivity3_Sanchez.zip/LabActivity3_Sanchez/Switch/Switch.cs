﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    class Switch
    {
        static void Main(string[] args)
        {
            string name;
            char gender;

            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi " + name + "!" + " Your gender is Male!");
                    break;
                case 'F': case 'f':
                    Console.WriteLine("\nHi " + name + "!" + " Your gender is Female!");
                    break;
                default:
                    Console.WriteLine("\nInvalid input. . . Try again. . . ");
                    break;
            }

            Console.ReadKey();
        }
    }
}
