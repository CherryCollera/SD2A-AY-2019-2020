﻿/*18-03650
 *Jobellee H. Ramos
 * SD2A
 * January 27, 2020
 * This program will display "Hello World"*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1_HelloWorld
{
    class Sample1_HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadLine();
        }
    }
}
