﻿/*18-03650
 Jobellee H. Ramos
 SD2A
 January 27, 2020
 This program will display the phrase "Hello World"*/

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
