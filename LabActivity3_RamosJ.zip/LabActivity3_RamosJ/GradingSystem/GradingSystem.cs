﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class GradingSystem
    {
        static void Main(string[] args)
        {

            string grade;
            int fgrade;

            Console.Write("Enter your final grade\t: ");
            grade = Console.ReadLine();


            if (grade == "inc" || grade == "INC")
            {
                Console.WriteLine("Incomplete");
            }
            else
            {
                fgrade = Convert.ToInt32(grade);

                if ((fgrade == 98) || (fgrade == 99) || (fgrade == 100))
                {
                    Console.WriteLine("Grade Equivalent\t: 1.00");
                    Console.WriteLine("Remarks\t\t\t: Excellent");
                }
                else if ((fgrade == 95) || (fgrade == 96) || (fgrade == 97))
                {
                    Console.WriteLine("Grade Equivalent\t: 1.25");
                    Console.WriteLine("Remarks\t\t\t: Excellent");
                }
                else if ((fgrade == 92) || (fgrade == 93) || (fgrade == 94))
                {
                    Console.WriteLine("Grade Equivalent\t: 1.50");
                    Console.WriteLine("Remarks\t\t\t: Very Good");
                }
                else if ((fgrade == 89) || (fgrade == 90) || (fgrade == 91))
                {
                    Console.WriteLine("Grade Equivalent\t: 1.75");
                    Console.WriteLine("Remarks\t\t\t: Very Good");
                }
                else if ((fgrade == 86) || (fgrade == 87) || (fgrade == 88))
                {
                    Console.WriteLine("Grade Equivalent\t: 2.00");
                    Console.WriteLine("Remarks\t\t\t: Good");
                }
                else if ((fgrade == 83) || (fgrade == 84) || (fgrade == 85))
                {
                    Console.WriteLine("Grade Equivalent\t: 2.25");
                    Console.WriteLine("Remarks\t\t\t: Good");
                }
                else if ((fgrade == 80) || (fgrade == 81) || (fgrade == 82))
                {
                    Console.WriteLine("Grade Equivalent\t: 2.50");
                    Console.WriteLine("Remarks\t\t\t: Fair");
                }
                else if ((fgrade == 77) || (fgrade == 78) || (fgrade == 79))
                {
                    Console.WriteLine("Grade Equivalent\t: 2.75");
                    Console.WriteLine("Remarks\t\t\t: Passed");
                }
                else if ((fgrade == 75) || (fgrade == 76))
                {
                    Console.WriteLine("Grade Equivalent\t: 3.00");
                    Console.WriteLine("Remarks\t\t\t: Passed");
                }
                else if ((fgrade == 72) || (fgrade == 73) || (fgrade == 74))
                {
                    Console.WriteLine("Grade Equivalent\t: 4.00");
                    Console.WriteLine("Remarks\t\t\t: Conditional (MT Only)");
                }
                else if ((fgrade == 60) || (fgrade == 61) || (fgrade == 62) || (fgrade == 63) || (fgrade == 64) || (fgrade == 65) || (fgrade == 66) || (fgrade == 67) || (fgrade == 68) || (fgrade == 69) || (fgrade == 70))
                {
                    Console.WriteLine("Grade Equivalent\t: 5.00");
                    Console.WriteLine("Remarks\t\t\t: Failed");
                }
                else
                {
                    Console.WriteLine("Invalid input");
                }
            }
            Console.ReadKey();
        }
    }
}
