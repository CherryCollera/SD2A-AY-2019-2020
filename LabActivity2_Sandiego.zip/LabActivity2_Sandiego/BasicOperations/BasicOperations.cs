﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2;
            double quotient,remainder;
            Console.Write("Enter first number:   ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:   ");
            num2 = Convert.ToInt32(Console.ReadLine());

            quotient = Convert.ToDouble(num1/num2);
            remainder = Convert.ToDouble(num1%num2);
            Console.Write("\nSum = {0} \nDifference = {1} \nProduct ={2} \nQuotient ={3:0.00} \nRemainder = {4:0.00}",num1 + num2,num1-num2,num1*num2,num1/num2,num1%num2);
            Console.ReadKey();
        }
    }
}
