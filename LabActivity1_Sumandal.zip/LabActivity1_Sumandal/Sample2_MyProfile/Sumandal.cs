﻿/*18-01269
Jonathan G. Sumandal
SD2A
February 2, 2020
This program will display my name, dob, course, year & section*/

using System;

namespace Sample2_MyProfile
{
    class Sumandal
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Name\t\t:\tJonathan G. Sumandal ");
            System.Console.WriteLine("\nDate of Birth\t:\tJune 16, 1982 ");
            System.Console.WriteLine("\nCourse\t\t:\tBS Computer Science ");
            System.Console.WriteLine("\nYear\t\t:\tII");
            System.Console.WriteLine("\nSection\t\t:\tSD2A ");
            System.Console.ReadKey();
        }
    }
}
