﻿using System;

namespace Sample3_InputMyName
{
    class Sumandal
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Name (Firstname Lastname)");
            string userName = Console.ReadLine();
            Console.WriteLine("Hello " + userName + "!!!");
            Console.WriteLine("Welcome to OOP environment.");
            Console.ReadKey();
        }
    }
}
