﻿/*18-01269
Jonathan G. Sumandal
SD2A
February 2, 2020
This program will display the phrase "Hello World"*/

using System;

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
