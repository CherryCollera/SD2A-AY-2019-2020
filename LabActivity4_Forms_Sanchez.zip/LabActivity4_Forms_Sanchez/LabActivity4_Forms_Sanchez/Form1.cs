﻿using System;
using System.Windows.Forms;

namespace LabActivity4_Forms_Sanchez
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getMessage_Click_Click(object sender, EventArgs e)
        {
            HappyBirthday hb = new HappyBirthday();
            MessageBox.Show(hb.GetMessage("Thomas"));
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    }
}
