﻿namespace LabActivity4_Forms_Sanchez
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Back = new System.Windows.Forms.Button();
            this.txtbox_SNumber = new System.Windows.Forms.TextBox();
            this.lbl_SNumber = new System.Windows.Forms.Label();
            this.txtbox_FNumber = new System.Windows.Forms.TextBox();
            this.lbl_FNumber = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Sub = new System.Windows.Forms.Button();
            this.btn_Mult = new System.Windows.Forms.Button();
            this.btn_Div = new System.Windows.Forms.Button();
            this.txtbox_Answer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(255, 394);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(139, 58);
            this.btn_Back.TabIndex = 13;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // txtbox_SNumber
            // 
            this.txtbox_SNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_SNumber.Location = new System.Drawing.Point(184, 105);
            this.txtbox_SNumber.Name = "txtbox_SNumber";
            this.txtbox_SNumber.Size = new System.Drawing.Size(210, 26);
            this.txtbox_SNumber.TabIndex = 17;
            // 
            // lbl_SNumber
            // 
            this.lbl_SNumber.AutoSize = true;
            this.lbl_SNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SNumber.Location = new System.Drawing.Point(23, 105);
            this.lbl_SNumber.Name = "lbl_SNumber";
            this.lbl_SNumber.Size = new System.Drawing.Size(155, 24);
            this.lbl_SNumber.TabIndex = 16;
            this.lbl_SNumber.Text = "Second Number:";
            // 
            // txtbox_FNumber
            // 
            this.txtbox_FNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_FNumber.Location = new System.Drawing.Point(184, 62);
            this.txtbox_FNumber.Name = "txtbox_FNumber";
            this.txtbox_FNumber.Size = new System.Drawing.Size(210, 26);
            this.txtbox_FNumber.TabIndex = 15;
            // 
            // lbl_FNumber
            // 
            this.lbl_FNumber.AutoSize = true;
            this.lbl_FNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FNumber.Location = new System.Drawing.Point(23, 62);
            this.lbl_FNumber.Name = "lbl_FNumber";
            this.lbl_FNumber.Size = new System.Drawing.Size(124, 24);
            this.lbl_FNumber.TabIndex = 14;
            this.lbl_FNumber.Text = "First Number:";
            // 
            // btn_Add
            // 
            this.btn_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.Location = new System.Drawing.Point(75, 178);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(103, 39);
            this.btn_Add.TabIndex = 18;
            this.btn_Add.Text = "+";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Sub
            // 
            this.btn_Sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sub.Location = new System.Drawing.Point(193, 178);
            this.btn_Sub.Name = "btn_Sub";
            this.btn_Sub.Size = new System.Drawing.Size(103, 39);
            this.btn_Sub.TabIndex = 18;
            this.btn_Sub.Text = "-";
            this.btn_Sub.UseVisualStyleBackColor = true;
            this.btn_Sub.Click += new System.EventHandler(this.btn_Sub_Click);
            // 
            // btn_Mult
            // 
            this.btn_Mult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mult.Location = new System.Drawing.Point(75, 236);
            this.btn_Mult.Name = "btn_Mult";
            this.btn_Mult.Size = new System.Drawing.Size(103, 39);
            this.btn_Mult.TabIndex = 18;
            this.btn_Mult.Text = "*";
            this.btn_Mult.UseVisualStyleBackColor = true;
            this.btn_Mult.Click += new System.EventHandler(this.btn_Mult_Click);
            // 
            // btn_Div
            // 
            this.btn_Div.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Div.Location = new System.Drawing.Point(193, 236);
            this.btn_Div.Name = "btn_Div";
            this.btn_Div.Size = new System.Drawing.Size(103, 39);
            this.btn_Div.TabIndex = 18;
            this.btn_Div.Text = "/";
            this.btn_Div.UseVisualStyleBackColor = true;
            this.btn_Div.Click += new System.EventHandler(this.btn_Div_Click);
            // 
            // txtbox_Answer
            // 
            this.txtbox_Answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_Answer.Location = new System.Drawing.Point(123, 316);
            this.txtbox_Answer.Name = "txtbox_Answer";
            this.txtbox_Answer.Size = new System.Drawing.Size(271, 38);
            this.txtbox_Answer.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 326);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 24);
            this.label1.TabIndex = 19;
            this.label1.Text = "Answer:";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 464);
            this.Controls.Add(this.txtbox_Answer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Div);
            this.Controls.Add(this.btn_Mult);
            this.Controls.Add(this.btn_Sub);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txtbox_SNumber);
            this.Controls.Add(this.lbl_SNumber);
            this.Controls.Add(this.txtbox_FNumber);
            this.Controls.Add(this.lbl_FNumber);
            this.Controls.Add(this.btn_Back);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox txtbox_SNumber;
        private System.Windows.Forms.Label lbl_SNumber;
        private System.Windows.Forms.TextBox txtbox_FNumber;
        private System.Windows.Forms.Label lbl_FNumber;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Sub;
        private System.Windows.Forms.Button btn_Mult;
        private System.Windows.Forms.Button btn_Div;
        private System.Windows.Forms.TextBox txtbox_Answer;
        private System.Windows.Forms.Label label1;
    }
}