﻿namespace LabActivity4_Forms_Sanchez
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Hide = new System.Windows.Forms.Button();
            this.btn_getMessage_Click = new System.Windows.Forms.Button();
            this.txtbox_Lname = new System.Windows.Forms.TextBox();
            this.lbl_Lname = new System.Windows.Forms.Label();
            this.txtbox_Fname = new System.Windows.Forms.TextBox();
            this.lbl_Fname = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(211, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "My Profile";
            // 
            // btn_Hide
            // 
            this.btn_Hide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Hide.Location = new System.Drawing.Point(262, 231);
            this.btn_Hide.Name = "btn_Hide";
            this.btn_Hide.Size = new System.Drawing.Size(139, 58);
            this.btn_Hide.TabIndex = 11;
            this.btn_Hide.Text = "Hide";
            this.btn_Hide.UseVisualStyleBackColor = true;
            this.btn_Hide.Click += new System.EventHandler(this.btn_Hide_Click);
            // 
            // btn_getMessage_Click
            // 
            this.btn_getMessage_Click.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getMessage_Click.Location = new System.Drawing.Point(40, 231);
            this.btn_getMessage_Click.Name = "btn_getMessage_Click";
            this.btn_getMessage_Click.Size = new System.Drawing.Size(206, 58);
            this.btn_getMessage_Click.TabIndex = 10;
            this.btn_getMessage_Click.Text = "Get My Profile";
            this.btn_getMessage_Click.UseVisualStyleBackColor = true;
            this.btn_getMessage_Click.Click += new System.EventHandler(this.btn_getMessage_Click_Click);
            // 
            // txtbox_Lname
            // 
            this.txtbox_Lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_Lname.Location = new System.Drawing.Point(135, 132);
            this.txtbox_Lname.Name = "txtbox_Lname";
            this.txtbox_Lname.Size = new System.Drawing.Size(403, 26);
            this.txtbox_Lname.TabIndex = 9;
            // 
            // lbl_Lname
            // 
            this.lbl_Lname.AutoSize = true;
            this.lbl_Lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lname.Location = new System.Drawing.Point(36, 132);
            this.lbl_Lname.Name = "lbl_Lname";
            this.lbl_Lname.Size = new System.Drawing.Size(91, 24);
            this.lbl_Lname.TabIndex = 8;
            this.lbl_Lname.Text = "Lastname";
            // 
            // txtbox_Fname
            // 
            this.txtbox_Fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_Fname.Location = new System.Drawing.Point(135, 89);
            this.txtbox_Fname.Name = "txtbox_Fname";
            this.txtbox_Fname.Size = new System.Drawing.Size(403, 26);
            this.txtbox_Fname.TabIndex = 7;
            // 
            // lbl_Fname
            // 
            this.lbl_Fname.AutoSize = true;
            this.lbl_Fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fname.Location = new System.Drawing.Point(36, 89);
            this.lbl_Fname.Name = "lbl_Fname";
            this.lbl_Fname.Size = new System.Drawing.Size(93, 24);
            this.lbl_Fname.TabIndex = 6;
            this.lbl_Fname.Text = "Firstname";
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(418, 231);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(139, 58);
            this.btn_Back.TabIndex = 12;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 333);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Hide);
            this.Controls.Add(this.btn_getMessage_Click);
            this.Controls.Add(this.txtbox_Lname);
            this.Controls.Add(this.lbl_Lname);
            this.Controls.Add(this.txtbox_Fname);
            this.Controls.Add(this.lbl_Fname);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Hide;
        private System.Windows.Forms.Button btn_getMessage_Click;
        private System.Windows.Forms.TextBox txtbox_Lname;
        private System.Windows.Forms.Label lbl_Lname;
        private System.Windows.Forms.TextBox txtbox_Fname;
        private System.Windows.Forms.Label lbl_Fname;
        private System.Windows.Forms.Button btn_Back;
    }
}