﻿using System;
using System.Windows.Forms;

namespace LabActivity4_Forms_Sanchez
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_getMessage_Click_Click(object sender, EventArgs e)
        {
            //HappyBirthday hb = new HappyBirthday();
            MessageBox.Show("\t\tHello " + txtbox_Fname.Text + " " + txtbox_Lname.Text + "\nDate of Birth\t\t:\tJanuary 28, 2000\nCourse\t\t\t:\tBS Computer Sience\nYear\t\t\t:\tII\nSection\t\t\t:\tA");
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    }
}
