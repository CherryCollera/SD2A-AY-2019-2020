﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstants
{
    class Sumandal
    {
        static void Main(string[] args)
        {
            int radius;
            const double pi = 3.14159;
            double AreaCircle;

            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());

            AreaCircle = pi * radius * radius;
            Console.Write("Radius: {0:0.0000}, Area: {1:0.0000}", radius, AreaCircle);
            Console.ReadKey();

        }
    }
}
