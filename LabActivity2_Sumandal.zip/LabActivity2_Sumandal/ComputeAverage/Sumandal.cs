﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputeAverage
{
    class Sumandal
    {
        static void Main(string[] args)
        {
            double g1, g2, g3, g4, g5;
            double average;

            Console.Write("Enter 5 Grades:\n");
            g1 = Convert.ToDouble(Console.ReadLine());
            g2 = Convert.ToDouble(Console.ReadLine());
            g3 = Convert.ToDouble(Console.ReadLine());
            g4 = Convert.ToDouble(Console.ReadLine());
            g5 = Convert.ToDouble(Console.ReadLine());
            average = (g1 + g2 + g3 + g4 + g5) / 5;
            Console.Write("The average is {0:00.000} ", average);
            Console.ReadKey();

        }
    }
}
