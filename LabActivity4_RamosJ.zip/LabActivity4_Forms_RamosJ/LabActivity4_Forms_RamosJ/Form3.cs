﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabActivity4_Forms_RamosJ
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_getMyProfile_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello " + txtbox_FName.Text + " " + txtbox_LName.Text + "!"
                + "\nDate of Birth:\tMarch 1, 1998"
                + "\nCourse:\t\tBS Information Technology"
                + "\nYear:\t\tII"
                + "\nSection:\t\tA");
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
