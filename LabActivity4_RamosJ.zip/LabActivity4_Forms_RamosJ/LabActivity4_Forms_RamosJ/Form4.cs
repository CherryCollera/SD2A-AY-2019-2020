﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabActivity4_Forms_RamosJ
{
    public partial class Form4 : Form
    {
        int a, b;
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Subtract_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtbox_FNumber.Text);
            b = Convert.ToInt32(txtbox_SNumber.Text);
            txtbox_Answer.Text = (a - b).ToString();
        }

        private void btn_Multiply_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtbox_FNumber.Text);
            b = Convert.ToInt32(txtbox_SNumber.Text);
            txtbox_Answer.Text = (a * b).ToString();
        }

        private void btn_Divide_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtbox_FNumber.Text);
            b = Convert.ToInt32(txtbox_SNumber.Text);
            txtbox_Answer.Text = (a / b).ToString();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtbox_FNumber.Text);
            b = Convert.ToInt32(txtbox_SNumber.Text);
            txtbox_Answer.Text = (a + b).ToString();
        }
    }
}
