﻿namespace LabActivity4_Forms_RamosJ
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_FNumber = new System.Windows.Forms.TextBox();
            this.txtbox_SNumber = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Multiply = new System.Windows.Forms.Button();
            this.btn_Subtract = new System.Windows.Forms.Button();
            this.btn_Divide = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbox_Answer = new System.Windows.Forms.TextBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Second Number:";
            // 
            // txtbox_FNumber
            // 
            this.txtbox_FNumber.Location = new System.Drawing.Point(149, 29);
            this.txtbox_FNumber.Name = "txtbox_FNumber";
            this.txtbox_FNumber.Size = new System.Drawing.Size(197, 20);
            this.txtbox_FNumber.TabIndex = 2;
            // 
            // txtbox_SNumber
            // 
            this.txtbox_SNumber.Location = new System.Drawing.Point(149, 79);
            this.txtbox_SNumber.Name = "txtbox_SNumber";
            this.txtbox_SNumber.Size = new System.Drawing.Size(196, 20);
            this.txtbox_SNumber.TabIndex = 3;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(52, 123);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(96, 30);
            this.btn_Add.TabIndex = 4;
            this.btn_Add.Text = "+";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Multiply
            // 
            this.btn_Multiply.Location = new System.Drawing.Point(52, 187);
            this.btn_Multiply.Name = "btn_Multiply";
            this.btn_Multiply.Size = new System.Drawing.Size(96, 30);
            this.btn_Multiply.TabIndex = 5;
            this.btn_Multiply.Text = "*";
            this.btn_Multiply.UseVisualStyleBackColor = true;
            this.btn_Multiply.Click += new System.EventHandler(this.btn_Multiply_Click);
            // 
            // btn_Subtract
            // 
            this.btn_Subtract.Location = new System.Drawing.Point(193, 123);
            this.btn_Subtract.Name = "btn_Subtract";
            this.btn_Subtract.Size = new System.Drawing.Size(98, 30);
            this.btn_Subtract.TabIndex = 6;
            this.btn_Subtract.Text = "-";
            this.btn_Subtract.UseVisualStyleBackColor = true;
            this.btn_Subtract.Click += new System.EventHandler(this.btn_Subtract_Click);
            // 
            // btn_Divide
            // 
            this.btn_Divide.Location = new System.Drawing.Point(193, 189);
            this.btn_Divide.Name = "btn_Divide";
            this.btn_Divide.Size = new System.Drawing.Size(98, 28);
            this.btn_Divide.TabIndex = 7;
            this.btn_Divide.Text = "/";
            this.btn_Divide.UseVisualStyleBackColor = true;
            this.btn_Divide.Click += new System.EventHandler(this.btn_Divide_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Answer:";
            // 
            // txtbox_Answer
            // 
            this.txtbox_Answer.Location = new System.Drawing.Point(101, 252);
            this.txtbox_Answer.Name = "txtbox_Answer";
            this.txtbox_Answer.Size = new System.Drawing.Size(130, 20);
            this.txtbox_Answer.TabIndex = 9;
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(278, 249);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(67, 23);
            this.btn_Back.TabIndex = 10;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 310);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.txtbox_Answer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Divide);
            this.Controls.Add(this.btn_Subtract);
            this.Controls.Add(this.btn_Multiply);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txtbox_SNumber);
            this.Controls.Add(this.txtbox_FNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_FNumber;
        private System.Windows.Forms.TextBox txtbox_SNumber;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Multiply;
        private System.Windows.Forms.Button btn_Subtract;
        private System.Windows.Forms.Button btn_Divide;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbox_Answer;
        private System.Windows.Forms.Button btn_Back;
    }
}