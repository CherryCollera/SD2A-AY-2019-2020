﻿namespace LabActivity4_Forms_RamosJ
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
