﻿using System;
using System.Windows.Forms;

namespace LabActivity4_Forms_RamosJ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_getMessage_2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Happy Birthday " + txtbox_FName.Text + " " + txtbox_LName.Text + "!");
        }

        private void btn_hide_2_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }
    }
}
