﻿namespace LabActivity4_Forms_RamosJ
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_FName = new System.Windows.Forms.TextBox();
            this.txtbox_LName = new System.Windows.Forms.TextBox();
            this.btn_getMessage_2 = new System.Windows.Forms.Button();
            this.btn_hide_2 = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last name:";
            // 
            // txtbox_FName
            // 
            this.txtbox_FName.Location = new System.Drawing.Point(144, 29);
            this.txtbox_FName.Name = "txtbox_FName";
            this.txtbox_FName.Size = new System.Drawing.Size(236, 20);
            this.txtbox_FName.TabIndex = 2;
            // 
            // txtbox_LName
            // 
            this.txtbox_LName.Location = new System.Drawing.Point(143, 82);
            this.txtbox_LName.Name = "txtbox_LName";
            this.txtbox_LName.Size = new System.Drawing.Size(236, 20);
            this.txtbox_LName.TabIndex = 3;
            // 
            // btn_getMessage_2
            // 
            this.btn_getMessage_2.Location = new System.Drawing.Point(143, 165);
            this.btn_getMessage_2.Name = "btn_getMessage_2";
            this.btn_getMessage_2.Size = new System.Drawing.Size(198, 47);
            this.btn_getMessage_2.TabIndex = 4;
            this.btn_getMessage_2.Text = "Get Message";
            this.btn_getMessage_2.UseVisualStyleBackColor = true;
            this.btn_getMessage_2.Click += new System.EventHandler(this.btn_getMessage_2_Click);
            // 
            // btn_hide_2
            // 
            this.btn_hide_2.Location = new System.Drawing.Point(301, 331);
            this.btn_hide_2.Name = "btn_hide_2";
            this.btn_hide_2.Size = new System.Drawing.Size(79, 31);
            this.btn_hide_2.TabIndex = 5;
            this.btn_hide_2.Text = "Hide";
            this.btn_hide_2.UseVisualStyleBackColor = true;
            this.btn_hide_2.Click += new System.EventHandler(this.btn_hide_2_Click);
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(386, 331);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(84, 31);
            this.btn_back.TabIndex = 8;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 410);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_hide_2);
            this.Controls.Add(this.btn_getMessage_2);
            this.Controls.Add(this.txtbox_LName);
            this.Controls.Add(this.txtbox_FName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_FName;
        private System.Windows.Forms.TextBox txtbox_LName;
        private System.Windows.Forms.Button btn_getMessage_2;
        private System.Windows.Forms.Button btn_hide_2;
        private System.Windows.Forms.Button btn_back;
    }
}