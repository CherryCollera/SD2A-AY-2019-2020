﻿using ClassExample2A_RamosJ;

class Declaration
{
    public string Color
    {
        get
        {
            return Color;
        }
        set
        {
            Color = value;
        }
    }
}
