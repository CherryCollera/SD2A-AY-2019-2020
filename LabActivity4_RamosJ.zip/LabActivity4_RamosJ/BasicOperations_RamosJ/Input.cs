﻿using BasicOperations_RamosJ;

class Input
{
    public void EnterInput()
    {

        System.Console.Write("Enter two values.\nInsert value for 1st number:\t");
        DeclareVar.num1 = System.Convert.ToInt32(System.Console.ReadLine());
        System.Console.Write("Insert value for 2nd number:\t");
        DeclareVar.num2 = System.Convert.ToInt32(System.Console.ReadLine());
    }
}