﻿using BasicOperations_RamosJ;

class Quotient
{
    public void ComputeQuotient()
    {
        DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        System.Console.WriteLine("Quotient:\t" + DeclareVar.quotient);
    }
}