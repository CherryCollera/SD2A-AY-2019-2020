﻿using System;

namespace BasicOperations_RamosJ
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Input ui = new Input();
                ui.EnterInput();

                Sum cs = new Sum();
                cs.ComputeSum();
                Difference cd = new Difference();
                cd.ComputeDifference();
                Product cp = new Product();
                cp.ComputeProduct();
                Quotient cq = new Quotient();
                cq.ComputeQuotient();
                Remainder cr = new Remainder();
                cr.ComputeRemainder();
            }
            catch(FormatException e)
            {
                Console.WriteLine(e.Message);
            }
           

            Console.ReadKey();
        }
    }
}
