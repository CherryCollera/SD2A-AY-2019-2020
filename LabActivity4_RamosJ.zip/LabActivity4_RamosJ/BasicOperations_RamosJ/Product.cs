﻿using BasicOperations_RamosJ;

class Product
{
    public void ComputeProduct()
    {
        DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
        System.Console.WriteLine("Product:\t" + DeclareVar.product);
    }
}