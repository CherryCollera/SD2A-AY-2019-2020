﻿using BasicOperations_RamosJ;

class Difference
{
    public void ComputeDifference()
    {
        DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
        System.Console.WriteLine("Difference:\t" + DeclareVar.difference);
    }
}