﻿using BasicOperations_RamosJ;

class Remainder
{
    public void ComputeRemainder()
    {
        DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
        System.Console.WriteLine("Remainder:\t" + DeclareVar.remainder);
    }
}