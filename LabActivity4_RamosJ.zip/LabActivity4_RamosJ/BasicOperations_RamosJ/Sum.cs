﻿using BasicOperations_RamosJ;

class Sum
{
    public void ComputeSum()
    {
        DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        System.Console.WriteLine("\nSum:\t\t" + DeclareVar.sum);
    }
}