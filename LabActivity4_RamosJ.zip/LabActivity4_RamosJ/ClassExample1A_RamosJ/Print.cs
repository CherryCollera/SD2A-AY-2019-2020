﻿using ClassExample1A_RamosJ;

class Print
{
    public void PrintDetails(string firstname, string lastname)
    {
        
        System.Console.Write("Hello " + firstname + " " + lastname + "!!!\nYou have created classes in OOP");
        return;
    }
}

