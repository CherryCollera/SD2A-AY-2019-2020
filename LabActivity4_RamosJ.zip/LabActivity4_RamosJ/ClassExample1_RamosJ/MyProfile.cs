﻿using ClassExample1_RamosJ;

class MyProfile
{
    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\n\t\t\tP R O F I L E");
        System.Console.WriteLine("Name:\t\t\tCherry Collera");
        System.Console.WriteLine("Birthday:\t\tMarch 1, 1999");
        System.Console.WriteLine("Course:\t\t\tBS in Info Tech Major in Network and Web Application");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\tA");
        System.Console.ReadLine();
    }
}

