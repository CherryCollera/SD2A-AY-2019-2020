﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEample1_Sanchez
{
    class Accept //1st Class
    {
        public string fname, lname;
        public void AcceptDetails()
        {
            Console.Write("Enter your firstname and lastname:\t");
            fname = Console.ReadLine();
            lname = Console.ReadLine();
        }
    }
}
