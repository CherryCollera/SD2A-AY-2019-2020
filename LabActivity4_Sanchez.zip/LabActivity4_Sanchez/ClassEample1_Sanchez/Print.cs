﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEample1_Sanchez
{
    class Print //2nd Class
    {
        public void PrintDetails(string fname, string lname)
        {
            Console.Write("Hello " + fname + " " + lname + "!!!\nYou have created classes in OOP");
        }
    }
}
