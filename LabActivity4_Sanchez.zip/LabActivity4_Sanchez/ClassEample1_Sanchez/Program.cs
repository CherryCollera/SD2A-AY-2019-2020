﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEample1_Sanchez
{
    class Program //4th Class
    {
        static void Main(string[] args)
        {
            Accept x = new Accept();
            x.AcceptDetails();
            Print y = new Print();
            y.PrintDetails(x.fname, x.lname);
            MyProfile z = new MyProfile();
            z.DisplayProfile(x.fname, x.lname);
            Console.ReadKey();
        }
    }
}
