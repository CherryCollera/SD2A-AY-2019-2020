﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEample1_Sanchez
{
    class MyProfile //3rd Class
    {
        public void DisplayProfile(string fname, string lname)
        {
            Console.WriteLine("\n\n\n\t\t\tP R O F I L E");
            Console.WriteLine("Name:\t\t\t{0} {1}", fname, lname);
            Console.WriteLine("Birthday:\t\tJanuary 1, 2000");
            Console.WriteLine("Course:\t\t\tBS in Computer Science Major in Software Development");
            Console.WriteLine("Year:\t\t\t2nd Year");
            Console.WriteLine("Section:\t\tA");
        }
    }
}
