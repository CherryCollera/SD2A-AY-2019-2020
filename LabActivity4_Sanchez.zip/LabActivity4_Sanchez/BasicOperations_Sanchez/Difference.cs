﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Difference //4th Class
    {
        public void Minus()
        {
            DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
            Console.WriteLine("\tDifference:\t{0}", DeclareVar.diff);

        }
    }
}
