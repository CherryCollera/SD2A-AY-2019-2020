﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Remainder
    {
        public void Rem()
        {
            DeclareVar.rem = DeclareVar.num1 % DeclareVar.num2;
            Console.WriteLine("\tRemainder:\t{0}", DeclareVar.rem);
        }
    }
}
