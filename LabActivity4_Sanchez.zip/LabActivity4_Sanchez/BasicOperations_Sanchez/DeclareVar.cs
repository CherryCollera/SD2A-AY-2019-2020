﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class DeclareVar //1st Class
    {
        public static int sum, diff, prod, quot, rem, num1, num2;

        /*internal void DeclareVar()
        {
            throw new NotImplementedException();
        }*/
    }
}
