﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Quotient //6th Class
    {
        public void Div()
        {
            DeclareVar.quot = DeclareVar.num1 / DeclareVar.num2;
            Console.WriteLine("\tQuotient:\t{0}", DeclareVar.quot);
        }
    }
}
