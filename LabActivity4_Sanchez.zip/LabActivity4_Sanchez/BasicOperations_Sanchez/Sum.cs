﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Sum //3rd Class
    {
        public void Add()
        {
            //DeclareVar da = new DeclareVar();
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            Console.WriteLine("\tSum:\t\t{0}", DeclareVar.sum);
        }
    }
}
