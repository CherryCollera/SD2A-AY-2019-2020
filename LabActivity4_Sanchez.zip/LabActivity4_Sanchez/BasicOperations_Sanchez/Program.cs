﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Program // Class
    {
        static void Main(string[] args)
        {
            //DeclareVar dv = new DeclareVar();
            try
            {
                Input i = new Input();
                i.InputNum();
                Sum s = new Sum();
                s.Add();
                Difference d = new Difference();
                d.Minus();
                Product p = new Product();
                p.Mult();
                Quotient q = new Quotient();
                q.Div();
                Remainder r = new Remainder();
                r.Rem();
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            
            Console.ReadKey();
        }
    }
}
