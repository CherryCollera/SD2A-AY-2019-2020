﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Input //2nd CLass
    {
        public void InputNum()
        {
            //DeclareVar d = new DeclareVar();
            Console.Write("Enter first number:\t");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:\t");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            //return;
        }
    }
}
