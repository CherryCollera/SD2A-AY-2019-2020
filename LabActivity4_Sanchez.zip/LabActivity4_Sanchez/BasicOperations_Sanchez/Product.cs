﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sanchez
{
    class Product //5th Class
    {
        public void Mult()
        {
            DeclareVar.prod = DeclareVar.num1 * DeclareVar.num2;
            Console.WriteLine("\tProduct:\t{0}", DeclareVar.prod);
        }
    }
}
