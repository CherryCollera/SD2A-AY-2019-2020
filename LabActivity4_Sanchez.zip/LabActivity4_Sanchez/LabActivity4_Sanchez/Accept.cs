﻿//EXAMPLE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Sanchez
{
    class Accept //1st Class
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            Console.Write("Enter your firstname and lastname:\t");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();
            Console.ReadKey();
        }
    }
}
