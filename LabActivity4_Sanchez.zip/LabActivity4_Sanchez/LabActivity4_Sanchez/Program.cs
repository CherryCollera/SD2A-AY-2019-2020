﻿//EXAMPLE
//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Sanchez
{
    class Program //4th Class
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
