﻿//Sanchez, Thomas Anthony D.    BSCS-SD2A   ICTC1023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2_Sanchez
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car(Console.ReadLine());
            Console.WriteLine(car.Describe());
            car = new Car(Console.ReadLine());
            Console.WriteLine(car.Describe());
            Console.ReadKey();
            Console.ReadKey();
        }
    }
}
