﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2, sum, difference, product;
            double quotient, modulo;

            Console.Write("Enter the first number\t: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number\t: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            sum = num1 + num2;
            Console.Write("\nSum\t\t\t: {0}", sum);

            difference = num1 - num2;
            Console.Write("\nDifference\t\t: {0}", difference);

            product = num1 * num2;
            Console.Write("\nProduct\t\t\t: {0}", product);

            quotient = num1 / num2;
            Console.Write("\nQuotient\t\t: {0:0.00}", quotient);

            modulo = num1 % num2;
            Console.Write("\nModulo\t\t\t: {0:0.00}", modulo);

            Console.ReadKey();

        }
    }
}
