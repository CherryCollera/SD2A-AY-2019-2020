﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputetheSum
{
    class ComputetheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter the first number\t: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number\t: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("\nSum: {0}", num1 + num2);
            Console.ReadLine();

            Console.ReadKey();

        }
    }
}