﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputeAverage
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {

            double g1, g2, g3, g4, g5;
            double average;

            Console.WriteLine("Enter five grades: ");
            g1 = Convert.ToInt32(Console.ReadLine());
            g2 = Convert.ToInt32(Console.ReadLine());
            g3 = Convert.ToInt32(Console.ReadLine());
            g4 = Convert.ToInt32(Console.ReadLine());
            g5 = Convert.ToInt32(Console.ReadLine());

            average = ((g1 + g2 + g3 + g4 + g5) / 5);

            Console.Write("\nThe average is: {0:0.000}", average);
            Console.ReadLine();

            Console.ReadKey();


        }
    }
}
