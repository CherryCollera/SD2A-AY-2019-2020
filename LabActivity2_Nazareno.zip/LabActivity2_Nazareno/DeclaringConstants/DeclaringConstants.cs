﻿/* NAZARENO, Jairuz D.
 * BSCS SD2A
 * This program show declaring constants. */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstants
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius;
            double AreaCircle;
            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());
            AreaCircle = pi * radius * radius;
            Console.Write("\nRadius: {0:0.0000}, Area: {1:0.0000}", radius, AreaCircle);
            Console.ReadLine();
        }
    }
}
