﻿/* NAZARENO, Jairuz D.
 * BSCS SD2A
 * This program will compute for the sum of 2 integer values */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputetheSum
{
    class ComputetheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nSum = " + (num1 + num2));
            Console.ReadLine();
        }
    }
}
