﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabActivity5_Nazareno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DialogResult dr = new DialogResult();


        private void BtnMessage_Click(object sender, EventArgs e)
        {
            dr= MessageBox.Show("Hello", "My Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                Calculator F2 = new Calculator();
                F2.Show();
                this.Hide();
            }
            else
            {
                this.Close();
            }
            
        }
    }
}
