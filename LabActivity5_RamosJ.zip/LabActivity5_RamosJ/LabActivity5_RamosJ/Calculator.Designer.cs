﻿using System;

namespace LabActivity5_RamosJ
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txtbox_Display = new System.Windows.Forms.TextBox();
            this.Btn_1 = new System.Windows.Forms.Button();
            this.Btn_2 = new System.Windows.Forms.Button();
            this.Btn_3 = new System.Windows.Forms.Button();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.Btn_4 = new System.Windows.Forms.Button();
            this.Btn_5 = new System.Windows.Forms.Button();
            this.Btn_6 = new System.Windows.Forms.Button();
            this.Btn_Sub = new System.Windows.Forms.Button();
            this.Btn_7 = new System.Windows.Forms.Button();
            this.Btn_8 = new System.Windows.Forms.Button();
            this.Btn_9 = new System.Windows.Forms.Button();
            this.Btn_Multiply = new System.Windows.Forms.Button();
            this.Btn_0 = new System.Windows.Forms.Button();
            this.Btn_Dot = new System.Windows.Forms.Button();
            this.Btn_Clear = new System.Windows.Forms.Button();
            this.Btn_Divide = new System.Windows.Forms.Button();
            this.Btn_Equals = new System.Windows.Forms.Button();
            this.Btn_Back = new System.Windows.Forms.Button();
            this.Btn_Hide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Txtbox_Display
            // 
            this.Txtbox_Display.Location = new System.Drawing.Point(12, 12);
            this.Txtbox_Display.Name = "Txtbox_Display";
            this.Txtbox_Display.Size = new System.Drawing.Size(200, 26);
            this.Txtbox_Display.TabIndex = 0;
            this.Txtbox_Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Txtbox_Display.TextChanged += new System.EventHandler(this.Txtbox_Display_TextChanged);
            // 
            // Btn_1
            // 
            this.Btn_1.BackColor = System.Drawing.Color.White;
            this.Btn_1.Location = new System.Drawing.Point(12, 44);
            this.Btn_1.Name = "Btn_1";
            this.Btn_1.Size = new System.Drawing.Size(45, 40);
            this.Btn_1.TabIndex = 2;
            this.Btn_1.Text = "1";
            this.Btn_1.UseVisualStyleBackColor = false;
            this.Btn_1.Click += new System.EventHandler(this.Btn_1_Click);
            // 
            // Btn_2
            // 
            this.Btn_2.BackColor = System.Drawing.Color.White;
            this.Btn_2.Location = new System.Drawing.Point(63, 44);
            this.Btn_2.Name = "Btn_2";
            this.Btn_2.Size = new System.Drawing.Size(45, 40);
            this.Btn_2.TabIndex = 3;
            this.Btn_2.Text = "2";
            this.Btn_2.UseVisualStyleBackColor = false;
            this.Btn_2.Click += new System.EventHandler(this.Btn_2_Click);
            // 
            // Btn_3
            // 
            this.Btn_3.BackColor = System.Drawing.Color.White;
            this.Btn_3.Location = new System.Drawing.Point(114, 44);
            this.Btn_3.Name = "Btn_3";
            this.Btn_3.Size = new System.Drawing.Size(45, 40);
            this.Btn_3.TabIndex = 4;
            this.Btn_3.Text = "3";
            this.Btn_3.UseVisualStyleBackColor = false;
            this.Btn_3.Click += new System.EventHandler(this.Btn_3_Click);
            // 
            // Btn_Add
            // 
            this.Btn_Add.BackColor = System.Drawing.Color.White;
            this.Btn_Add.Location = new System.Drawing.Point(165, 44);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(45, 40);
            this.Btn_Add.TabIndex = 5;
            this.Btn_Add.Text = "+";
            this.Btn_Add.UseVisualStyleBackColor = false;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // Btn_4
            // 
            this.Btn_4.BackColor = System.Drawing.Color.White;
            this.Btn_4.Location = new System.Drawing.Point(12, 90);
            this.Btn_4.Name = "Btn_4";
            this.Btn_4.Size = new System.Drawing.Size(45, 40);
            this.Btn_4.TabIndex = 6;
            this.Btn_4.Text = "4";
            this.Btn_4.UseVisualStyleBackColor = false;
            this.Btn_4.Click += new System.EventHandler(this.Btn_4_Click);
            // 
            // Btn_5
            // 
            this.Btn_5.BackColor = System.Drawing.Color.White;
            this.Btn_5.Location = new System.Drawing.Point(63, 90);
            this.Btn_5.Name = "Btn_5";
            this.Btn_5.Size = new System.Drawing.Size(45, 40);
            this.Btn_5.TabIndex = 7;
            this.Btn_5.Text = "5";
            this.Btn_5.UseVisualStyleBackColor = false;
            this.Btn_5.Click += new System.EventHandler(this.Btn_5_Click);
            // 
            // Btn_6
            // 
            this.Btn_6.BackColor = System.Drawing.Color.White;
            this.Btn_6.Location = new System.Drawing.Point(114, 90);
            this.Btn_6.Name = "Btn_6";
            this.Btn_6.Size = new System.Drawing.Size(45, 40);
            this.Btn_6.TabIndex = 8;
            this.Btn_6.Text = "6";
            this.Btn_6.UseVisualStyleBackColor = false;
            this.Btn_6.Click += new System.EventHandler(this.Btn_6_Click);
            // 
            // Btn_Sub
            // 
            this.Btn_Sub.BackColor = System.Drawing.Color.White;
            this.Btn_Sub.Location = new System.Drawing.Point(165, 90);
            this.Btn_Sub.Name = "Btn_Sub";
            this.Btn_Sub.Size = new System.Drawing.Size(45, 40);
            this.Btn_Sub.TabIndex = 9;
            this.Btn_Sub.Text = "-";
            this.Btn_Sub.UseVisualStyleBackColor = false;
            this.Btn_Sub.Click += new System.EventHandler(this.Btn_Sub_Click);
            // 
            // Btn_7
            // 
            this.Btn_7.BackColor = System.Drawing.Color.White;
            this.Btn_7.Location = new System.Drawing.Point(12, 136);
            this.Btn_7.Name = "Btn_7";
            this.Btn_7.Size = new System.Drawing.Size(45, 40);
            this.Btn_7.TabIndex = 10;
            this.Btn_7.Text = "7";
            this.Btn_7.UseVisualStyleBackColor = false;
            this.Btn_7.Click += new System.EventHandler(this.Btn_7_Click);
            // 
            // Btn_8
            // 
            this.Btn_8.BackColor = System.Drawing.Color.White;
            this.Btn_8.Location = new System.Drawing.Point(63, 136);
            this.Btn_8.Name = "Btn_8";
            this.Btn_8.Size = new System.Drawing.Size(45, 40);
            this.Btn_8.TabIndex = 11;
            this.Btn_8.Text = "8";
            this.Btn_8.UseVisualStyleBackColor = false;
            this.Btn_8.Click += new System.EventHandler(this.Btn_8_Click_1);
            // 
            // Btn_9
            // 
            this.Btn_9.BackColor = System.Drawing.Color.White;
            this.Btn_9.Location = new System.Drawing.Point(114, 136);
            this.Btn_9.Name = "Btn_9";
            this.Btn_9.Size = new System.Drawing.Size(45, 40);
            this.Btn_9.TabIndex = 12;
            this.Btn_9.Text = "9";
            this.Btn_9.UseVisualStyleBackColor = false;
            this.Btn_9.Click += new System.EventHandler(this.Btn_9_Click_1);
            // 
            // Btn_Multiply
            // 
            this.Btn_Multiply.BackColor = System.Drawing.Color.White;
            this.Btn_Multiply.Location = new System.Drawing.Point(165, 136);
            this.Btn_Multiply.Name = "Btn_Multiply";
            this.Btn_Multiply.Size = new System.Drawing.Size(45, 40);
            this.Btn_Multiply.TabIndex = 13;
            this.Btn_Multiply.Text = "*";
            this.Btn_Multiply.UseVisualStyleBackColor = false;
            this.Btn_Multiply.Click += new System.EventHandler(this.Btn_Multiply_Click);
            // 
            // Btn_0
            // 
            this.Btn_0.BackColor = System.Drawing.Color.White;
            this.Btn_0.Location = new System.Drawing.Point(12, 182);
            this.Btn_0.Name = "Btn_0";
            this.Btn_0.Size = new System.Drawing.Size(45, 40);
            this.Btn_0.TabIndex = 14;
            this.Btn_0.Text = "0";
            this.Btn_0.UseVisualStyleBackColor = false;
            this.Btn_0.Click += new System.EventHandler(this.Btn_0_Click_1);
            // 
            // Btn_Dot
            // 
            this.Btn_Dot.BackColor = System.Drawing.Color.White;
            this.Btn_Dot.Location = new System.Drawing.Point(63, 182);
            this.Btn_Dot.Name = "Btn_Dot";
            this.Btn_Dot.Size = new System.Drawing.Size(45, 40);
            this.Btn_Dot.TabIndex = 15;
            this.Btn_Dot.Text = ".";
            this.Btn_Dot.UseVisualStyleBackColor = false;
            this.Btn_Dot.Click += new System.EventHandler(this.Btn_Dot_Click);
            // 
            // Btn_Clear
            // 
            this.Btn_Clear.BackColor = System.Drawing.Color.White;
            this.Btn_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Clear.Location = new System.Drawing.Point(114, 182);
            this.Btn_Clear.Name = "Btn_Clear";
            this.Btn_Clear.Size = new System.Drawing.Size(45, 40);
            this.Btn_Clear.TabIndex = 16;
            this.Btn_Clear.Text = "Clear";
            this.Btn_Clear.UseVisualStyleBackColor = false;
            this.Btn_Clear.Click += new System.EventHandler(this.Btn_Clear_Click);
            // 
            // Btn_Divide
            // 
            this.Btn_Divide.BackColor = System.Drawing.Color.White;
            this.Btn_Divide.Location = new System.Drawing.Point(165, 182);
            this.Btn_Divide.Name = "Btn_Divide";
            this.Btn_Divide.Size = new System.Drawing.Size(45, 40);
            this.Btn_Divide.TabIndex = 17;
            this.Btn_Divide.Text = "/";
            this.Btn_Divide.UseVisualStyleBackColor = false;
            this.Btn_Divide.Click += new System.EventHandler(this.Btn_Divide_Click);
            // 
            // Btn_Equals
            // 
            this.Btn_Equals.BackColor = System.Drawing.Color.White;
            this.Btn_Equals.Location = new System.Drawing.Point(165, 228);
            this.Btn_Equals.Name = "Btn_Equals";
            this.Btn_Equals.Size = new System.Drawing.Size(45, 40);
            this.Btn_Equals.TabIndex = 18;
            this.Btn_Equals.Text = "=";
            this.Btn_Equals.UseVisualStyleBackColor = false;
            this.Btn_Equals.Click += new System.EventHandler(this.Btn_Equals_Click);
            // 
            // Btn_Back
            // 
            this.Btn_Back.BackColor = System.Drawing.Color.White;
            this.Btn_Back.Location = new System.Drawing.Point(12, 228);
            this.Btn_Back.Name = "Btn_Back";
            this.Btn_Back.Size = new System.Drawing.Size(70, 40);
            this.Btn_Back.TabIndex = 19;
            this.Btn_Back.Text = "Back";
            this.Btn_Back.UseVisualStyleBackColor = false;
            this.Btn_Back.Click += new System.EventHandler(this.Btn_Back_Click);
            // 
            // Btn_Hide
            // 
            this.Btn_Hide.BackColor = System.Drawing.Color.White;
            this.Btn_Hide.Location = new System.Drawing.Point(89, 228);
            this.Btn_Hide.Name = "Btn_Hide";
            this.Btn_Hide.Size = new System.Drawing.Size(70, 40);
            this.Btn_Hide.TabIndex = 20;
            this.Btn_Hide.Text = "Hide";
            this.Btn_Hide.UseVisualStyleBackColor = false;
            this.Btn_Hide.Click += new System.EventHandler(this.Btn_Hide_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(227, 285);
            this.Controls.Add(this.Btn_Hide);
            this.Controls.Add(this.Btn_Back);
            this.Controls.Add(this.Btn_Equals);
            this.Controls.Add(this.Btn_Divide);
            this.Controls.Add(this.Btn_Clear);
            this.Controls.Add(this.Btn_Dot);
            this.Controls.Add(this.Btn_0);
            this.Controls.Add(this.Btn_Multiply);
            this.Controls.Add(this.Btn_9);
            this.Controls.Add(this.Btn_8);
            this.Controls.Add(this.Btn_7);
            this.Controls.Add(this.Btn_Sub);
            this.Controls.Add(this.Btn_6);
            this.Controls.Add(this.Btn_5);
            this.Controls.Add(this.Btn_4);
            this.Controls.Add(this.Btn_Add);
            this.Controls.Add(this.Btn_3);
            this.Controls.Add(this.Btn_2);
            this.Controls.Add(this.Btn_1);
            this.Controls.Add(this.Txtbox_Display);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Location = new System.Drawing.Point(143, 378);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txtbox_Display;
        private System.Windows.Forms.Button Btn_1;
        private System.Windows.Forms.Button Btn_2;
        private System.Windows.Forms.Button Btn_3;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.Button Btn_4;
        private System.Windows.Forms.Button Btn_5;
        private System.Windows.Forms.Button Btn_6;
        private System.Windows.Forms.Button Btn_Sub;
        private System.Windows.Forms.Button Btn_7;
        private System.Windows.Forms.Button Btn_8;
        private System.Windows.Forms.Button Btn_9;
        private System.Windows.Forms.Button Btn_Multiply;
        private System.Windows.Forms.Button Btn_0;
        private System.Windows.Forms.Button Btn_Dot;
        private System.Windows.Forms.Button Btn_Clear;
        private System.Windows.Forms.Button Btn_Divide;
        private System.Windows.Forms.Button Btn_Equals;
        private System.Windows.Forms.Button Btn_Back;
        private System.Windows.Forms.Button Btn_Hide;
        //private EventHandler btn_Eight_Click;
        // private EventHandler btn_Nine_Click;
        // private EventHandler btn_Zero_Click;
    }
}

