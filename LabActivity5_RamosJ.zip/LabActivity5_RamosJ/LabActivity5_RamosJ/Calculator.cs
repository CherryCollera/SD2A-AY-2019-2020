﻿using System;
using System.Windows.Forms;

namespace LabActivity5_RamosJ
{
    public partial class Calculator : Form
    {

        double total1 = 0;
        double total2 = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        public Calculator()
        {
            InitializeComponent();
        }
        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void Btn_1_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_1.Text;
        }

        private void Btn_2_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_2.Text;
        }

        private void Btn_3_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_3.Text;
        }

        private void Btn_4_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_4.Text;
        }

        private void Btn_5_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_5.Text;
        }

        private void Btn_6_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_6.Text;
        }

        private void Btn_7_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_7.Text;
        }

        private void Btn_8_Click_1(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_8.Text;
        }

        private void Btn_9_Click_1(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_9.Text;
        }

        private void Btn_0_Click_1(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_0.Text;
        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Clear();
        }

        private void Btn_Multiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(Txtbox_Display.Text);
            Txtbox_Display.Clear();
            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(Txtbox_Display.Text);
            Txtbox_Display.Clear();
            minusButtonClicked = false;
            plusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void Btn_Equals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)
            {
                total2 = total1 + double.Parse(Txtbox_Display.Text);
            }
            else if (minusButtonClicked == true)
            {
                total2 = total1 - double.Parse(Txtbox_Display.Text);
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = total1 + double.Parse(Txtbox_Display.Text);
            }
            else if (divideButtonClicked == true)
            {
                total2 = total1 / double.Parse(Txtbox_Display.Text);
            }
            Txtbox_Display.Text = total2.ToString(); total1 = 0;
        }

        private void Btn_Sub_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(Txtbox_Display.Text);
            Txtbox_Display.Clear();
            minusButtonClicked = true;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void Btn_Divide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(Txtbox_Display.Text);
            Txtbox_Display.Clear();
            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }

        private void Btn_Dot_Click(object sender, EventArgs e)
        {
            Txtbox_Display.Text = Txtbox_Display.Text + Btn_Dot.Text;
        }

        private void Btn_Back_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
            
        }

        private void Txtbox_Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn_Hide_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
