﻿namespace LabActivity5_RamosJ
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Integer = new System.Windows.Forms.Button();
            this.Btn_Float = new System.Windows.Forms.Button();
            this.Btn_Double = new System.Windows.Forms.Button();
            this.Txtbox_SNumber = new System.Windows.Forms.TextBox();
            this.Txtbox_FNumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_ComputeSum = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_Integer
            // 
            this.Btn_Integer.BackColor = System.Drawing.Color.White;
            this.Btn_Integer.Location = new System.Drawing.Point(26, 33);
            this.Btn_Integer.Name = "Btn_Integer";
            this.Btn_Integer.Size = new System.Drawing.Size(195, 43);
            this.Btn_Integer.TabIndex = 0;
            this.Btn_Integer.Text = "Integer";
            this.Btn_Integer.UseVisualStyleBackColor = false;
            this.Btn_Integer.Click += new System.EventHandler(this.Btn_Integer_Click);
            // 
            // Btn_Float
            // 
            this.Btn_Float.BackColor = System.Drawing.Color.White;
            this.Btn_Float.Location = new System.Drawing.Point(273, 33);
            this.Btn_Float.Name = "Btn_Float";
            this.Btn_Float.Size = new System.Drawing.Size(195, 43);
            this.Btn_Float.TabIndex = 1;
            this.Btn_Float.Text = "Float";
            this.Btn_Float.UseVisualStyleBackColor = false;
            this.Btn_Float.Click += new System.EventHandler(this.Btn_Float_Click);
            // 
            // Btn_Double
            // 
            this.Btn_Double.BackColor = System.Drawing.Color.White;
            this.Btn_Double.Location = new System.Drawing.Point(519, 33);
            this.Btn_Double.Name = "Btn_Double";
            this.Btn_Double.Size = new System.Drawing.Size(195, 43);
            this.Btn_Double.TabIndex = 2;
            this.Btn_Double.Text = "Double";
            this.Btn_Double.UseVisualStyleBackColor = false;
            this.Btn_Double.Click += new System.EventHandler(this.Btn_Double_Click);
            // 
            // Txtbox_SNumber
            // 
            this.Txtbox_SNumber.Location = new System.Drawing.Point(519, 158);
            this.Txtbox_SNumber.Name = "Txtbox_SNumber";
            this.Txtbox_SNumber.Size = new System.Drawing.Size(137, 20);
            this.Txtbox_SNumber.TabIndex = 4;
            // 
            // Txtbox_FNumber
            // 
            this.Txtbox_FNumber.Location = new System.Drawing.Point(177, 158);
            this.Txtbox_FNumber.Name = "Txtbox_FNumber";
            this.Txtbox_FNumber.Size = new System.Drawing.Size(137, 20);
            this.Txtbox_FNumber.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Enter first number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(402, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Enter second number:";
            // 
            // Btn_ComputeSum
            // 
            this.Btn_ComputeSum.BackColor = System.Drawing.Color.White;
            this.Btn_ComputeSum.Location = new System.Drawing.Point(273, 234);
            this.Btn_ComputeSum.Name = "Btn_ComputeSum";
            this.Btn_ComputeSum.Size = new System.Drawing.Size(195, 43);
            this.Btn_ComputeSum.TabIndex = 8;
            this.Btn_ComputeSum.Text = "Compute Sum";
            this.Btn_ComputeSum.UseVisualStyleBackColor = false;
            this.Btn_ComputeSum.Click += new System.EventHandler(this.Btn_ComputeSum_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.BackColor = System.Drawing.Color.White;
            this.Btn_Exit.Location = new System.Drawing.Point(603, 276);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(110, 23);
            this.Btn_Exit.TabIndex = 9;
            this.Btn_Exit.Text = "Exit";
            this.Btn_Exit.UseVisualStyleBackColor = false;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(744, 321);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_ComputeSum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Txtbox_FNumber);
            this.Controls.Add(this.Txtbox_SNumber);
            this.Controls.Add(this.Btn_Double);
            this.Controls.Add(this.Btn_Float);
            this.Controls.Add(this.Btn_Integer);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Integer;
        private System.Windows.Forms.Button Btn_Float;
        private System.Windows.Forms.Button Btn_Double;
        private System.Windows.Forms.TextBox Txtbox_SNumber;
        private System.Windows.Forms.TextBox Txtbox_FNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_ComputeSum;
        private System.Windows.Forms.Button Btn_Exit;
    }
}