﻿namespace LabActivity5_RamosJ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_getMessage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_getMessage
            // 
            this.Btn_getMessage.BackColor = System.Drawing.Color.White;
            this.Btn_getMessage.Location = new System.Drawing.Point(57, 148);
            this.Btn_getMessage.Name = "Btn_getMessage";
            this.Btn_getMessage.Size = new System.Drawing.Size(158, 52);
            this.Btn_getMessage.TabIndex = 0;
            this.Btn_getMessage.Text = "Get Message";
            this.Btn_getMessage.UseVisualStyleBackColor = false;
            this.Btn_getMessage.Click += new System.EventHandler(this.Btn_getMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.Btn_getMessage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btn_getMessage;
    }
}