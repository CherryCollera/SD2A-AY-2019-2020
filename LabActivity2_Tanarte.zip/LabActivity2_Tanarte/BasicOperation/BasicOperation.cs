﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class BasicOperation
    {
        static void Main(string[] args)
        {
            int num1, num2, sum, diff, prod;
            double quot, rem;
           
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            sum = num1 + num2;
            diff = num1 - num2;
            prod = num1 * num2;
            quot =Convert.ToDouble(num1 / num2);
            rem = Convert.ToDouble(num1 % num2);


            Console.Write("\nSum = {0} \nDifference = {1} \nProduct = {2} \nQuotient = {3:0.00} \nRemainder = {4:0.00}", sum, diff, prod, quot, rem);
            Console.ReadKey();
        }
    }
}
