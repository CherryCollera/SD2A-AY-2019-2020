﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity2_Tanarte
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nSum = {0}   ", num1 + num2);
            Console.ReadKey();

        }
    }
}
