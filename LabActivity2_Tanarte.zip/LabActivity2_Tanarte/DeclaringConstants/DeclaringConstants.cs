﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstants
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double areaCircle, radius;

            Console.Write("Enter Radius: ");
            radius = Convert.ToDouble(Console.ReadLine());
            areaCircle = radius * pi * radius;

            Console.Write("\nRadius: {0:0.0000} \nArea: {1:0.0000}", radius, areaCircle);
            Console.ReadKey();
        }
    }
}
