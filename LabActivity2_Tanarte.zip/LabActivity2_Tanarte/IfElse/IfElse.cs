﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class IfElse
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n");

            if (num1>num2)
            {
                Console.WriteLine(num1 + " Is Greater Than " + num2);
            }
            else if (num1 == num2)
            {
                Console.WriteLine(num1 + " Is Equal To " + num2);
            }
            else
                Console.WriteLine(num2 + " Is Greater Than " + num1);

            Console.ReadKey();
        }
    }
}
