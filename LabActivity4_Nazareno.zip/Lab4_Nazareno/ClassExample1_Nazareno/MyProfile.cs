﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Nazareno
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tJairuz Nazareno");
            System.Console.WriteLine("Birthday:\t\tMarch 21, 2000");
            System.Console.WriteLine("Course:\t\t\tBS Computer Science Major in Software Technology");
            System.Console.WriteLine("Year:\t\t\t2ndYear");
            System.Console.WriteLine("Section:\t\tA");
            System.Console.ReadLine();
        }
    }
}
