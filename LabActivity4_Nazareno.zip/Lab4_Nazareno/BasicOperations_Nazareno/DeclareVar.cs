﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class DeclareVar
    {
        public static double num1, num2, sum, difference, product, quotient, remainder;
    }
}
