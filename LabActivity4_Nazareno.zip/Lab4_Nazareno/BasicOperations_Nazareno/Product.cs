﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Product
    {
        public void Multiply()
        {
            DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
            Console.Write("\nProduct\t\t:\t" + DeclareVar.product);
            
        }
    }
}
