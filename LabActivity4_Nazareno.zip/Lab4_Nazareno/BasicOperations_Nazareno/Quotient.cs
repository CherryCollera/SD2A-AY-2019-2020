﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Quotient
    {
        public void Divide()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
            Console.Write("\nQuotient\t:\t{0:0.00}", DeclareVar.quotient);
            
        }
    }
}
