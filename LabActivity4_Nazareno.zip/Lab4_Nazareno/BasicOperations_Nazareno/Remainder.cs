﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Remainder
    {
        public void Modulo()
        {
            DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
            Console.Write("\nRemainder\t:\t{0:0.00}", DeclareVar.remainder);
            
        }
    }
}
