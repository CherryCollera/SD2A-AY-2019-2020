﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-=BASIC OPERATIONS=-");
            try
            {
                Input i = new Input();
                i.InputNumbers();
                Sum s = new Sum();
                s.Add();
                Difference d = new Difference();
                d.Subtract();
                Product p = new Product();
                p.Multiply();
                Quotient q = new Quotient();
                q.Divide();
                Remainder r = new Remainder();
                r.Modulo();
            }
            catch(System.FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
