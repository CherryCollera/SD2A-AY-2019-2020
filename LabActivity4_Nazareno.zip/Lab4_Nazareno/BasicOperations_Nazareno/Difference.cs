﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Difference
    {
        public void Subtract()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
            Console.Write("\nDifference\t:\t" + DeclareVar.difference);
            
        }
    }
}
