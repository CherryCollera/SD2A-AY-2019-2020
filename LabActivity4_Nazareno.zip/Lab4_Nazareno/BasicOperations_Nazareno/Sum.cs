﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Sum
    {
        public void Add()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            Console.Write("\nSum\t\t:\t" + DeclareVar.sum);
            
        }
    }
}
