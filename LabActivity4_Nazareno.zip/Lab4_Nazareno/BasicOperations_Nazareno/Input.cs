﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Nazareno
{
    class Input
    {
        public void InputNumbers()
        {
            Console.Write("Enter first number\t:\t");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number\t:\t");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
        }
    }
}
