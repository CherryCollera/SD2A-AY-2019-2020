﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Nazareno
{
    class Print
    {
        public void PrintDetails(string firstname, string lastname)
        {
            System.Console.Write("Hello " + firstname + " " + lastname + "!!!\nYou have created classes in OOP");
            return;

        }
    }
}
